using System.Collections.Immutable;
using XuanYu.Core.Results;
using XuanYu.World.Map;

namespace XuanYu.Editor.MapEditing;

public sealed partial class MapEditSession
{
    public EngineResult EditRegionVertices(MapRegionId regionId, ImmutableArray<MapPoint> vertices)
    {
        if (!GuardWriteThread()) return Fail("NotOnWriteThread", "编辑区域顶点必须在编辑写线程执行。");
        var region = _currentMap.Regions.FirstOrDefault(item => item.RegionId == regionId);
        if (region is null) return Fail("UnknownRegion", "区域不存在。");
        if (MapLayerRules.Find(_currentMap.Layers, region.LayerId)?.IsLocked == true)
            return Fail("RegionLayerLocked", "区域所属图层已锁定。");
        return CommitMapChange(
            map => map with { Regions = map.Regions.Replace(region, region with { Vertices = vertices }) },
            MapEditReason.RegionGeometryEdited,
            map => UpsertRegionSpatialIndex(map, regionId));
    }

    public EngineResult EditRoadPoints(MapRoadId roadId, ImmutableArray<MapPoint> points)
    {
        if (!GuardWriteThread()) return Fail("NotOnWriteThread", "编辑道路节点必须在编辑写线程执行。");
        var road = _currentMap.Roads.FirstOrDefault(item => item.RoadId == roadId);
        if (road is null) return Fail("UnknownRoad", "道路不存在。");
        if (MapLayerRules.Find(_currentMap.Layers, road.LayerId)?.IsLocked == true)
            return Fail("RoadLayerLocked", "道路所属图层已锁定。");
        return CommitMapChange(
            map => map with { Roads = map.Roads.Replace(road, road with { Points = points }) },
            MapEditReason.RoadGeometryEdited);
    }

    public EngineResult InsertRoadVertex(MapRoadId roadId, int segmentIndex, MapPoint point)
    {
        if (!GuardWriteThread()) return Fail("NotOnWriteThread", "新增道路节点必须在编辑写线程执行。");
        var road = _currentMap.Roads.FirstOrDefault(item => item.RoadId == roadId);
        if (road is null) return Fail("UnknownRoad", "道路不存在。");
        if (MapLayerRules.Find(_currentMap.Layers, road.LayerId)?.IsLocked == true)
            return Fail("RoadLayerLocked", "道路所属图层已锁定。");
        if (segmentIndex < 0 || segmentIndex >= road.Points.Length - 1)
            return Fail("InvalidRoadSegment", "新增节点必须位于有效道路线段上。");
        return EditRoadPoints(roadId, road.Points.Insert(segmentIndex + 1, point));
    }

    public EngineResult DeleteRoadVertex(MapRoadId roadId, int vertexIndex)
    {
        if (!GuardWriteThread()) return Fail("NotOnWriteThread", "删除道路节点必须在编辑写线程执行。");
        var road = _currentMap.Roads.FirstOrDefault(item => item.RoadId == roadId);
        if (road is null) return Fail("UnknownRoad", "道路不存在。");
        if (road.Points.Length <= 2) return Fail("RoadMinimumVertices", "道路至少保留两个节点。");
        if (vertexIndex < 0 || vertexIndex >= road.Points.Length)
            return Fail("InvalidRoadVertex", "道路节点索引无效。");
        return EditRoadPoints(roadId, road.Points.RemoveAt(vertexIndex));
    }

    public EngineResult CreateMarker(MapMarker marker)
    {
        if (!GuardWriteThread()) return Fail("NotOnWriteThread", "创建地图标记必须在编辑写线程执行。");
        return CommitMapChange(map => map with { Markers = (map.Markers.IsDefault ? [] : map.Markers).Add(marker) }, MapEditReason.MarkerCreated);
    }

    public EngineResult EditMarkerPosition(MapMarkerId markerId, MapPoint position)
    {
        if (!GuardWriteThread()) return Fail("NotOnWriteThread", "编辑地图标记必须在编辑写线程执行。");
        var marker = (MapSessionMarkers()).FirstOrDefault(item => item.MarkerId == markerId);
        if (marker is null) return Fail("UnknownMarker", "地图标记不存在。");
        if (marker.IsLocked) return Fail("MarkerLocked", "地图标记已锁定。");
        if (MapLayerRules.Find(_currentMap.Layers, marker.LayerId)?.IsLocked == true)
            return Fail("MarkerLayerLocked", "地图标记所属图层已锁定。");
        return CommitMapChange(map => map with { Markers = map.Markers.Replace(marker, marker with { Position = position }) }, MapEditReason.MarkerGeometryEdited);
    }

    ImmutableArray<MapMarker> MapSessionMarkers() => _currentMap.Markers.IsDefault ? [] : _currentMap.Markers;
}
