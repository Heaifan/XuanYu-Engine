using System.Collections.Concurrent;
namespace XuanYu.Editor.UI;

static partial class Win32ViewportHost
{
    const uint WM_MOUSEMOVE = 0x0200, WM_LBUTTONDOWN = 0x0201, WM_LBUTTONUP = 0x0202;
    const uint WM_RBUTTONDOWN = 0x0204, WM_RBUTTONUP = 0x0205;
    const uint WM_MBUTTONDOWN = 0x0207, WM_MBUTTONUP = 0x0208, WM_MOUSEWHEEL = 0x020a;
    const uint WM_CAPTURECHANGED = 0x0215, WM_KILLFOCUS = 0x0008;
    const uint WM_CANCELMODE = 0x001f;
    const int VK_MENU = 0x12, VK_LWIN = 0x5b, VK_RWIN = 0x5c;
    static readonly ConcurrentDictionary<nint, Action<NativePointerMessage>> InputSinks = new();

    public static void SetInputSink(nint hwnd, Action<NativePointerMessage>? sink)
    {
        if (hwnd == 0) return;
        if (sink is null) InputSinks.TryRemove(hwnd, out _);
        else InputSinks[hwnd] = sink;
    }

    static nint RouteWndProc(nint hWnd, uint msg, nint wParam, nint lParam)
    {
        if (InputSinks.TryGetValue(hWnd, out var sink) && IsPointerMessage(msg))
        {
            if (msg == WM_MOUSEMOVE) TrackMouseLeave(hWnd);
            var before = GetCapture();
            if (msg is WM_LBUTTONDOWN or WM_MBUTTONDOWN) SetCapture(hWnd);
            var after = GetCapture();
            var target = msg == WM_CAPTURECHANGED ? lParam : 0;
            var point = ReadPoint(hWnd, msg, lParam);
            sink(new NativePointerMessage(
                msg, (int)wParam, point.X, point.Y, hWnd, before, after, target,
                IsAltDown(), 1, IsMetaDown()));
        }
        RouteKeyboardMessage(hWnd, msg, wParam, lParam);
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }

    static bool IsPointerMessage(uint msg) => NativePointerSourceBoundary.IsPointerMessage(msg);

    static void TrackMouseLeave(nint hwnd)
    {
        var request = new TRACKMOUSEEVENT(
            (uint)System.Runtime.InteropServices.Marshal.SizeOf<TRACKMOUSEEVENT>(), 2, hwnd);
        TrackMouseEvent(ref request);
    }

    static (int X, int Y) ReadPoint(nint hWnd, uint msg, nint lParam)
    {
        var point = new POINT { X = LoWord(lParam), Y = HiWord(lParam) };
        if (msg == WM_MOUSEWHEEL) ScreenToClient(hWnd, ref point);
        return (point.X, point.Y);
    }

    public static bool HasMouseCapture(nint hwnd) => hwnd != 0 && GetCapture() == hwnd;

    public static void ReleaseMouseCapture(nint hwnd)
    {
        if (HasMouseCapture(hwnd)) ReleaseCapture();
    }

    static int LoWord(nint value) => unchecked((short)((long)value & 0xffff));
    static int HiWord(nint value) => unchecked((short)(((long)value >> 16) & 0xffff));
    static bool IsAltDown() => (GetKeyState(VK_MENU) & 0x8000) != 0;
    static bool IsMetaDown() => (GetKeyState(VK_LWIN) & 0x8000) != 0 ||
        (GetKeyState(VK_RWIN) & 0x8000) != 0;

    [System.Runtime.InteropServices.DllImport("user32")]
    static extern nint SetCapture(nint hWnd);
    [System.Runtime.InteropServices.DllImport("user32")]
    static extern nint GetCapture();
    [System.Runtime.InteropServices.DllImport("user32")]
    [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
    static extern bool ReleaseCapture();
    [System.Runtime.InteropServices.DllImport("user32")]
    static extern short GetKeyState(int key);
    [System.Runtime.InteropServices.DllImport("user32")]
    [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
    static extern bool ScreenToClient(nint hWnd, ref POINT point);
    [System.Runtime.InteropServices.DllImport("user32")]
    [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
    static extern bool TrackMouseEvent(ref TRACKMOUSEEVENT request);

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    struct POINT
    {
        public int X;
        public int Y;
    }

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    struct TRACKMOUSEEVENT(uint cbSize, uint dwFlags, nint hwndTrack)
    {
        public uint cbSize = cbSize;
        public uint dwFlags = dwFlags;
        public nint hwndTrack = hwndTrack;
        public nint hwndHover;
        public uint dwHoverTime;
    }
}
